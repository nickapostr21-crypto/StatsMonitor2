package com.example.syswidget

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock
import android.widget.RemoteViews
import java.io.File
import java.util.Locale

class StatsWidget : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH = "com.example.syswidget.STATS_REFRESH"
        private const val FAST_MS = 3_000L    // screen on
        private const val SLOW_MS = 60_000L   // screen off
        private const val PREFS = "stats_prefs"
        private const val GB = 1_073_741_824.0

        private val BAR_IDS = intArrayOf(
            R.id.pb0, R.id.pb1, R.id.pb2, R.id.pb3, R.id.pb4, R.id.pb5, R.id.pb6, R.id.pb7
        )

        private var deviceInfo: Triple<String, String, String>? = null

        private fun refreshIntent(ctx: Context): PendingIntent {
            val i = Intent(ctx, StatsWidget::class.java).setAction(ACTION_REFRESH)
            return PendingIntent.getBroadcast(
                ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun schedule(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            val delay = if (pm.isInteractive) FAST_MS else SLOW_MS
            am.setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + delay,
                refreshIntent(ctx)
            )
        }

        private fun cancel(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(refreshIntent(ctx))
        }

        private fun fmt(f: String, vararg a: Any) = String.format(Locale.US, f, *a)

        private fun readLong(path: String): Long? =
            try { File(path).readText().trim().toLong() } catch (_: Exception) { null }

        private fun firstInt(path: String): Long? = try {
            Regex("""\d+""").find(File(path).readText())?.value?.toLong()
        } catch (_: Exception) { null }

        private fun prop(name: String): String = try {
            val p = Runtime.getRuntime().exec(arrayOf("getprop", name))
            val out = p.inputStream.bufferedReader().readText().trim()
            p.destroy()
            out
        } catch (_: Exception) { "" }

        // model, android version, HyperOS version (read once, then cached)
        private fun info(): Triple<String, String, String> {
            deviceInfo?.let { return it }
            val model = prop("ro.product.marketname").ifEmpty { Build.MODEL }
            val android = "Android ${Build.VERSION.RELEASE}"
            val inc = prop("ro.mi.os.version.incremental")
            val ver = Regex("""OS(\d+(?:\.\d+)*)""").find(inc)?.groupValues?.get(1)
                ?: prop("ro.mi.os.version.name").removePrefix("OS").ifEmpty { null }
            val hyper = if (ver != null) "HyperOS $ver" else "HyperOS N/A"
            val t = Triple(model, android, hyper)
            deviceInfo = t
            return t
        }

        private fun uptime(): String {
            val s = SystemClock.elapsedRealtime() / 1000
            return fmt("Uptime %dd %d:%02d", s / 86400, (s % 86400) / 3600, (s % 3600) / 60)
        }

        // Highest current core frequency
        private fun cpuMax(): String {
            var maxKhz = -1L
            for (i in 0 until 16) {
                if (!File("/sys/devices/system/cpu/cpu$i").exists()) break
                val v = readLong("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq")
                    ?: readLong("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_cur_freq")
                if (v != null && v > maxKhz) maxKhz = v
            }
            if (maxKhz <= 0) return "CPU N/A"
            val mhz = maxKhz / 1000.0
            return if (mhz >= 1000) fmt("CPU %.2f GHz", mhz / 1000) else fmt("CPU %.0f MHz", mhz)
        }

        // idle/total jiffies per core from /proc/stat (blocked on most Android 8+ phones)
        private fun readCpuStat(): Map<Int, LongArray>? = try {
            val m = HashMap<Int, LongArray>()
            File("/proc/stat").forEachLine { line ->
                if (line.startsWith("cpu") && line.length > 3 && line[3].isDigit()) {
                    val p = line.trim().split(Regex("\\s+"))
                    val id = p[0].substring(3).toInt()
                    val v = p.drop(1).take(8).map { it.toLong() }
                    m[id] = longArrayOf(v[3] + v[4], v.sum())
                }
            }
            if (m.isEmpty()) null else m
        } catch (_: Exception) { null }

        private fun freqPercent(i: Int): Int {
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val cur = readLong(base + "scaling_cur_freq") ?: readLong(base + "cpuinfo_cur_freq") ?: return 0
            val max = readLong(base + "cpuinfo_max_freq") ?: readLong(base + "scaling_max_freq")
                ?: (if (i >= 6) 2_000_000L else 1_700_000L)
            val min = readLong(base + "cpuinfo_min_freq") ?: 500_000L
            if (max <= min) return 0
            return ((cur - min) * 100 / (max - min)).toInt().coerceIn(0, 100)
        }

        // Real usage if /proc/stat is readable, otherwise frequency position between min and max
        private fun coreLoad(ctx: Context): IntArray {
            val out = IntArray(8)
            val stat = readCpuStat()
            if (stat != null) {
                val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val ed = sp.edit()
                var ok = false
                for (i in 0 until 8) {
                    val cur = stat[i] ?: continue
                    val pi = sp.getLong("i$i", -1L)
                    val pt = sp.getLong("t$i", -1L)
                    if (pi >= 0 && cur[1] > pt) {
                        val dt = cur[1] - pt
                        val di = cur[0] - pi
                        out[i] = (100 * (dt - di) / dt).toInt().coerceIn(0, 100)
                        ok = true
                    }
                    ed.putLong("i$i", cur[0]).putLong("t$i", cur[1])
                }
                ed.apply()
                if (ok) return out
            }
            for (i in 0 until 8) out[i] = freqPercent(i)
            return out
        }

        private fun gpuFreqMhz(): Int? {
            val paths = ArrayList<String>()
            try {
                File("/sys/class/devfreq").listFiles()?.forEach {
                    if (it.name.contains("mali") || it.name.contains("gpu")) paths.add(it.path + "/cur_freq")
                }
            } catch (_: Exception) { }
            paths.addAll(listOf("/sys/kernel/ged/hal/current_freqency", "/sys/kernel/gpu/gpu_clock"))
            for (p in paths) {
                val v = firstInt(p) ?: continue
                val mhz = when {
                    v > 10_000_000L -> v / 1_000_000L
                    v > 10_000L -> v / 1_000L
                    else -> v
                }
                if (mhz in 1..3000) return mhz.toInt()
            }
            return null
        }

        private fun gpuLoad(): Int? {
            val paths = ArrayList<String>()
            paths.addAll(listOf(
                "/sys/kernel/gpu/gpu_busy",
                "/sys/kernel/ged/hal/gpu_utilization",
                "/sys/module/ged/parameters/gpu_loading"
            ))
            try {
                File("/sys/class/devfreq").listFiles()?.forEach {
                    if (it.name.contains("mali") || it.name.contains("gpu")) paths.add(it.path + "/load")
                }
            } catch (_: Exception) { }
            for (p in paths) {
                val v = firstInt(p) ?: continue
                if (v in 0..100) return v.toInt()
            }
            return null
        }

        private fun gpu(): String {
            val f = gpuFreqMhz()
            val l = gpuLoad()
            if (f == null && l == null) return "GPU N/A"
            return "GPU ${f?.let { "${it}MHz" } ?: "--"} ${l?.let { "$it%" } ?: "--"}"
        }

        private fun disk(): String {
            val st = StatFs(Environment.getDataDirectory().path)
            val total = st.blockCountLong * st.blockSizeLong
            val used = total - st.availableBlocksLong * st.blockSizeLong
            return fmt("Disk %.1f/%.0fG", used / GB, total / GB)
        }

        private fun ram(ctx: Context): String {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val usedMb = (mi.totalMem - mi.availMem) / 1_048_576
            val totalMb = mi.totalMem / 1_048_576
            return "RAM $usedMb/${totalMb}MB"
        }

        private fun render(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val v = RemoteViews(ctx.packageName, R.layout.widget_stats)

            val (model, android, hyper) = info()
            v.setTextViewText(R.id.tv_model, model)
            v.setTextViewText(R.id.tv_android, android)
            v.setTextViewText(R.id.tv_hyper, hyper)
            v.setTextViewText(R.id.tv_uptime, uptime())

            val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10
            v.setTextViewText(R.id.tv_batt, if (level >= 0) "Bat ${level * 100 / scale}% $temp°C" else "Bat --")

            v.setTextViewText(R.id.tv_cpu, cpuMax())
            val load = coreLoad(ctx)
            for (i in 0 until 8) v.setProgressBar(BAR_IDS[i], 100, load[i], false)

            v.setTextViewText(R.id.tv_gpu, gpu())
            v.setTextViewText(R.id.tv_disk, disk())
            v.setTextViewText(R.id.tv_ram, ram(ctx))

            v.setOnClickPendingIntent(R.id.root, refreshIntent(ctx)) // tap = refresh
            mgr.updateAppWidget(ids, v)
        }
    }

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        render(ctx, mgr, ids)
        schedule(ctx)
    }

    override fun onEnabled(ctx: Context) = schedule(ctx)

    override fun onDisabled(ctx: Context) = cancel(ctx)

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_REFRESH) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, StatsWidget::class.java))
            if (ids.isNotEmpty()) {
                render(ctx, mgr, ids)
                schedule(ctx)
            }
        }
    }
}
